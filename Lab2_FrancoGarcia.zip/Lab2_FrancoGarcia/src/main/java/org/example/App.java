package org.example;

import jakarta.persistence.*;
import java.util.Scanner;

public class App
{
    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("Lab2_FrancoGarcia");
    public static void main( String[] args )
    {
        Scanner input = new Scanner(System.in);
        int exitNum = 1 ;


        do
        {   /* =============== CREATES A MENU FOR USER =============== */
            System.out.println("\nWELCOME TO OUR CUSTOMER DATABASE \n\n");
            System.out.println("Select an option: \n" +
                               "1. Add a customer\n" +
                               "2. Get customer details\n" +
                               "3. Update customer phone number\n" +
                               "4. Delete a customer\n" +
                               "0. Exit program\n\n" +
                               "Enter your option: ");
            int userChoice = input.nextInt();

            // If user chooses option 1, it will ask user for details and add a customer
            if (userChoice == 1) {
                System.out.println("\n\nADD A CUSTOMER\n\n");
                System.out.println("Enter company name: ");
                String companyName = input.nextLine();
                System.out.println("Enter contact name: ");
                String contactName = input.nextLine();
                System.out.println("Enter contact title: ");
                String contactTitle = input.nextLine();
                System.out.println("Enter address: ");
                String address = input.nextLine();
                System.out.println("Enter city: ");
                String city = input.nextLine();
                System.out.println("Enter region: ");
                String region = input.nextLine();
                System.out.println("Enter postal code: ");
                String postalCode = input.nextLine();
                System.out.println("Enter country: ");
                String country = input.nextLine();
                System.out.println("Enter phone number: ");
                int phoneNumber = input.nextInt();
                System.out.println("Enter fax number: ");
                int faxNumber = input.nextInt();
                addCustomer(companyName, contactName, contactTitle, address, city, region, postalCode, country, phoneNumber, faxNumber);
                System.out.println("\nA customer has been successfully added!\n");

            } else if (userChoice == 2) {
                // Option 2, asks user for the customer ID and gets customer details
                System.out.println("\n\nGET CUSTOMER DETAILS\n\n");
                System.out.println("Enter customer ID: ");
                String cusID = input.nextLine();
                getCustomer(cusID);

            } else if (userChoice == 3) {
                // This will update a customer
                System.out.println("\n\nUPDATE CUSTOMER PHONE NUMBER\n\n");
                System.out.println("Enter customer ID: ");
                String cusID = input.nextLine();
                int newPhone = input.nextInt();


            } else if (userChoice == 4) {
                // This will delete a customer
                System.out.println("\n\nDELETE A CUSTOMER\n\n");
                System.out.println("Enter customer ID: ");
                String cusID = input.nextLine();
                int deleter = 0;
                while (deleter == 0) {
                    System.out.println("Are you sure you want to delete this customer?\n" +
                            "1. Yes\n" +
                            "2. No\n\n" +
                            "Enter choice: ");
                    int sure = input.nextInt();
                    if (sure == 1) {
                        deleteCustomer(cusID);
                        System.out.println("\n");
                    } else if (sure == 2) {
                        deleter = 1;
                    } else {
                        System.out.println("\nPlease enter a valid option.\n");
                    }
                }


            } else if (userChoice == 0) {
                // This will exit the program
                System.out.println("\n\nThank you for using our Customer Database!\n\n");
                exitNum = userChoice;
            } else {
                System.out.println("\nPlease enter a valid option.\n");
            }

        }while(exitNum!=0);
    }

//    customerId, companyName, contactName, contactTitle, address, city, region, postalCode, country, phoneNumber, faxNumber

    /* =============== Method to CREATE AND ADD A NEW CUSTOMER =============== */
    public static void addCustomer(String companyName,
                                   String contactName,
                                   String contactTitle,
                                   String address,
                                   String city, String region,
                                   String postalCode, String country,
                                   int phoneNumber, int faxNumber){
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = null;
        try{
            et = em.getTransaction();
            et.begin();
            Customer emp = new Customer();
            emp.setCompanyName(companyName);
            emp.setContactName(contactName);
            emp.setContactTitle(contactTitle);
            emp.setAddress(address);
            emp.setCity(city);
            emp.setRegion(region);
            emp.setPostalCode(postalCode);
            emp.setCountry(country);
            emp.setPhoneNumber(phoneNumber);
            emp.setFaxNumber(faxNumber);
            emp.setCustomerId(emp.getCompanyName(), emp.getPhoneNumber());
            em.persist(emp);
            et.commit();
        }catch (Exception ex){
            if(et!=null){
                et.rollback();
            }
        }finally {
            em.close();
        }
    }

    /* =============== Method to FETCH CUSTOMER DETAILS =============== */
    public static void getCustomer(String id){
        EntityManager em = emf.createEntityManager();
        try{

            TypedQuery<Customer> tq = em.createQuery("select c from Customer c where c.customerId=:id", Customer.class);
            tq.setParameter("id", id);
            Customer c = tq.getSingleResult();
            System.out.println("\n\nHere are the customer details: \n" +
                               "Company Name: " + c.getCompanyName() + "\n" +
                               "Contact Name: " + c.getContactName());
        }catch(Exception ex){
            ex.printStackTrace();
        }finally {
            {
                em.close();
            }
        }
    }

    /* =============== Method to UPDATE PHONE NUMBER =============== */
    public static void updateCustomer(String id, int phoneNew){
        EntityManager em = emf.createEntityManager();
        try{

            TypedQuery<Customer> tq = em.createQuery("update c.phone from Customer c where c.customerId=:id", Customer.class);
            tq.setParameter("id", id);
            tq.setParameter("phone", phoneNew);
            Customer c = tq.getSingleResult();
            System.out.println("\n\nCustomer has been successfully updated!\n\n");
        }catch(Exception ex){
            ex.printStackTrace();
        }finally {
            {
                em.close();
            }
        }
    }

    /* =============== Method to DELETE A CUSTOMER =============== */
    public static void deleteCustomer(String id){
        EntityManager em = emf.createEntityManager();
        try{

            TypedQuery<Customer> tq = em.createQuery("delete c from Customer c where c.customerId=:id", Customer.class);
            tq.setParameter("id", id);
            Customer c = tq.getSingleResult();
            System.out.println("\nCustomer " + c.getCustomerId() + " has been successfully deleted.");
        }catch(Exception ex){
            ex.printStackTrace();
        }finally {
            {
                em.close();
            }
        }
    }
}
