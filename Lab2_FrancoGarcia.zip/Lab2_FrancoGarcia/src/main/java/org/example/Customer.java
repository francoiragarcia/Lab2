package org.example;

import jakarta.persistence.Entity;
import jakarta.persistence.*;

@Entity
@Table(name="customers")

public class Customer {
    private static final long serialVersionUID = 1L;

    /* ===== Convert columns into Java variables ===== */
    @Id
    //@Column(name="CustomerID", unique = true)
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="CustomerID") private String customerId;
    @Column(name="CompanyName") private String companyName;
    @Column(name="ContactName") private String contactName;
    @Column(name="ContactTitle") private String contactTitle;
    @Column(name="Address") private String address;
    @Column(name="City") private String city;
    @Column(name="Region") private String region;
    @Column(name="PostalCode") private String postalCode;
    @Column(name="Country") private String country;
    @Column(name="Phone") private int phoneNumber;
    @Column(name="Fax") private int faxNumber;

    /* ===== Creates the get attribute for each column ===== */
    public static long getSerialVersionUID() { return serialVersionUID; }

    public String getCustomerId() { return customerId; }
    public String getCompanyName() { return companyName; }
    public String getContactName() { return contactName; }
    public String getContactTitle() { return contactTitle; }
    public String getAddress() { return address; }
    public String getCity() { return city; }
    public String getRegion() { return region; }
    public String getPostalCode() { return postalCode; }
    public String getCountry() { return country; }
    public int getPhoneNumber() { return phoneNumber; }
    public int getFaxNumber() { return faxNumber; }

    /* ===== Creates the set attribute for each column ===== */
    public void setCustomerId(String companyName, int phoneNumber) {
        String temp1 = companyName.substring(0,3);
        String convert = String.valueOf(phoneNumber);
        String temp2 = convert.substring(convert.length()-3);
        this.customerId = temp1 + temp2;
    }
    public void setCompanyName(String companyName) { this.companyName = companyName; }
    public void setContactName(String contactName) { this.contactName = contactName; }
    public void setContactTitle (String contactTitle) { this.contactTitle = contactTitle; }
    public void setAddress(String address) { this.address = address; }
    public void setCity(String city) { this.city = city; }
    public void setRegion(String region) { this.region = region; }
    public void setPostalCode(String postalCode) { this.postalCode = postalCode; }
    public void setCountry(String country) { this.country = country; }
    public void setPhoneNumber(int phoneNumber) { this.phoneNumber = phoneNumber; }
    public void setFaxNumber(int faxNumber) { this.faxNumber = faxNumber; }
}
